import express from "express";

const app = express();

// Codesanbox does not need PORT :)
app.listen(() => console.log(`Listening!`));
