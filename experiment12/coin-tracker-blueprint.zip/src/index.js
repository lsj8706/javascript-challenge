import "./styles.css";

const API_URL = "https://api.coinpaprika.com/v1/tickers";
